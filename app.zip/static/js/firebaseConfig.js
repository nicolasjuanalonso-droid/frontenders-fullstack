const firebaseConfig = {
  apiKey: "AIzaSyCJjHN0-JfZNpSi3slEBgzQvR3NtdQR-BM",
  authDomain: "frontenders-56cae.firebaseapp.com",
  projectId: "frontenders-56cae",
  storageBucket: "frontenders-56cae.firebasestorage.app",
  messagingSenderId: "975807831715",
  appId: "1:975807831715:web:b7ed3fd0d6b9bb1e4a2916"
};